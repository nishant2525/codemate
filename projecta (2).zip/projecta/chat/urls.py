from django.urls import path
from .views import index
from django.views.decorators.csrf import csrf_exempt
app_name = 'chat'

urlpatterns = [
    path('chat/',csrf_exempt(index),name='index'),
]